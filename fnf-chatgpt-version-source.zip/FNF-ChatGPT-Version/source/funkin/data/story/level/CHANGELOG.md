# Story Mode Level Data Schema Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.2]
### Added
- Added `capsule` field to change the Level's capsule name on the Freeplay menu.

## [1.0.1]
### Added
- Added `visible` attribute.

## [1.0.0]
Initial release.
