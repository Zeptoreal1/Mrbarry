package funkin.ui;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
 * FNF: ChatGPT Version visual language.
 * No external texture assets, no per-frame bitmap generation or post-processing.
 * Each object is created only once when the menu opens.
 */
class ChatGPTTheme
{
  public static final NAVY:FlxColor = 0xFF11132C;
  public static final PANEL:FlxColor = 0xFF28264F;
  public static final PURPLE:FlxColor = 0xFF865DFF;
  public static final CYAN:FlxColor = 0xFF48D9F4;
  public static final PINK:FlxColor = 0xFFFF69B4;
  public static final WHITE:FlxColor = 0xFFF7F7FF;
  public static final MUTED:FlxColor = 0xFFB6BBDA;

  static function rect(x:Float, y:Float, w:Float, h:Float, color:FlxColor, alpha:Float = 1):FlxSprite
  {
    var sprite = new FlxSprite(x, y);
    sprite.makeGraphic(Std.int(Math.max(1, w)), Std.int(Math.max(1, h)), color);
    sprite.alpha = alpha;
    sprite.scrollFactor.set(0, 0);
    sprite.active = false;
    return sprite;
  }

  public static function text(x:Float, y:Float, w:Float, value:String, size:Int, color:FlxColor):FlxText
  {
    var label = new FlxText(x, y, w, value, size);
    label.color = color;
    label.scrollFactor.set(0, 0);
    label.active = false;
    return label;
  }

  public static function addBackdrop(state:FlxState, section:String):Void
  {
    // A saturated but readable color scheme, with very little overdraw.
    state.add(rect(0, 0, FlxG.width, FlxG.height, NAVY));
    state.add(rect(0, 0, 13, FlxG.height, PURPLE));
    state.add(rect(13, 0, 5, FlxG.height, CYAN));
    state.add(rect(18, 0, FlxG.width - 18, 8, PINK));
    state.add(rect(FlxG.width * 0.58, FlxG.height * 0.12, FlxG.width * 0.4, 7, PURPLE, 0.6));
    state.add(rect(FlxG.width * 0.72, FlxG.height * 0.18, FlxG.width * 0.22, 7, CYAN, 0.5));
    state.add(rect(FlxG.width * 0.66, FlxG.height * 0.75, FlxG.width * 0.29, 7, PINK, 0.5));
    state.add(rect(40, FlxG.height - 48, FlxG.width - 80, 2, 0xFF49466F));
    state.add(text(42, FlxG.height - 39, FlxG.width - 80, 'FNF: CHATGPT VERSION  /  $section', 13, MUTED));
  }

  public static function addHeading(state:FlxState, section:String):Void
  {
    state.add(text(76, 46, 760, "FRIDAY NIGHT FUNKIN'", 18, CYAN));
    state.add(text(72, 72, 920, 'CHATGPT VERSION', 55, WHITE));
    state.add(rect(76, 149, 145, 5, PINK));
    state.add(text(76, 167, 600, section, 18, MUTED));
  }

  public static function addPauseBrand(state:FlxState):Void
  {
    state.add(rect(26, 20, 7, 76, CYAN));
    state.add(text(46, 23, 500, 'CHATGPT VERSION', 28, WHITE));
    state.add(text(47, 60, 450, 'PAUSED  /  STAY ON BEAT', 17, PINK));
  }
}
