# FNF: ChatGPT Version — Changes (8 November 2026)

- Added `ChatGPTTheme` procedural UI primitives with dark navy, lavender, cyan and pink palette.
- Rebuilt the main menu with modern selection cards and labels instead of animated image atlases.
- Simplified options background to avoid the previous full-screen HSV shader pass.
- Added title, pause, Freeplay, story and gameplay branding.
- Added a persistent opt-in Performance Mode option that suppresses decorative hit splashes and hold covers, without changing hit logic.
- Replaced main menu pixel-perfect touch overlap with bounding box touch overlap.
- Applied smooth 160ms focus transitions and synchronized fade-out for menu labels.
- Hardened Linux URL opening against shell interpretation of URL characters.
- Unified desktop and mobile URL validation.
- Hardened sandbox file-path boundary checks.
- Added basic archive size and traversal guards in the ZIP reader.
- Updated source metadata with a distinct community-fork package identity.
- Added security review, build guide and 9 static regression checks.

The uploaded snapshot does not include art/audio submodules. No compiled binary or measured FPS benchmark is claimed.
