# FNF: ChatGPT Version — automatic ZIP-to-APK building

This is an **unofficial** Friday Night Funkin' source fork. It is not affiliated with the Funkin' Crew or OpenAI.

## What to upload to GitHub

At your repository root upload **one file**:

- `fnf-chatgpt-version-source.zip` — the complete edited source, already packaged.

Then create **one GitHub Actions file** with the provided standalone contents:

- `.github/workflows/build-fnf.yml`

**The workflow file must exist *outside* the ZIP**. GitHub does not activate workflows from ZIP archives automatically. On GitHub, use **Add file → Create new file**, enter `.github/workflows/build-fnf.yml` as the filename (GitHub automatically creates the parent directories), paste the downloaded YAML contents, then commit. You do not need to extract the source ZIP or create any source folders manually.

## Build

1. Open **Actions → Build FNF ChatGPT Version → Run workflow**.
2. Keep **android** selected for an APK, or select **html5** for a web build.
3. When GitHub Actions completes successfully, download the `FNF-ChatGPT-Version-Android-APK` artifact from the run summary.
4. Unzip the *GitHub Actions artifact* to obtain `FNF-ChatGPT-Version.apk`.

Every later push replacing the source ZIP automatically starts a new Android build. Android uses the pinned NDK version documented by the upstream mobile compiling guide.

## Limitations

- Not a confirmed passing cloud build. The archive and workflow were syntax/structure checked and the included 9 source contract checks passed, but compilation wasn't possible in the local environment. If a cloud run fails, check the GitHub Actions step log.
- The original upload did not include the proprietary `assets` submodule. The workflow fetches the public upstream asset repository at build time. Its contents have **a separate licence restricting redistribution**; do not publish APKs or copied assets without permission. Assets from a moving upstream branch may be incompatible with the snapshot of code in this ZIP; if this occurs, a compatible commit is required.
- The workflow uses a **temporary, newly generated signing key** if the release APK is unsigned. APKs signed using that temporary key cannot reliably be installed as updates over APKs from another run; uninstalling the previous personal test build may be necessary and can lose app data. Store releases need your own stable protected signing key.
- Native dependencies are numerous and may exceed default GitHub Actions free build resources or timeouts. The action has a 180-minute limit, not a promise the build will finish successfully.
- Do not use the official game's package identifier or publishing credentials; this fork uses its own unofficial application ID.
