# FNF: ChatGPT Version — GitHub Actions build from one source ZIP

This is an **unofficial fork**. GitHub Actions builds the game; no local Android Studio install and no manual source-folder extraction are required.

## Files to put in your GitHub repository

1. Upload **`fnf-chatgpt-version-source.zip`** to the repository root. Keep that filename exactly.
2. Open your existing **`.github/workflows/build-fnf.yml`** in GitHub, press **Edit**, replace it with the downloaded **`build-fnf-fixed.yml`** contents, and commit. The file path in GitHub must remain `.github/workflows/build-fnf.yml`. The workflow cannot be loaded from inside a ZIP.
3. GitHub Actions automatically starts a build when you commit either file, or use **Actions → Build FNF ChatGPT Version → Run workflow** and select **android**.
4. On a *successful* run, download **FNF-ChatGPT-Version-Android-APK** under **Artifacts**. Inside it is `FNF-ChatGPT-Version.apk`.

## If it fails

Download the artifact **FNF-ChatGPT-Version-Build-Logs** from the failed run. It contains setup/build logs collected by the workflow. Also open the failed step in the GitHub Actions UI, copy its last error lines, and provide them for troubleshooting. An annotation "Process completed with exit code 1" alone is insufficient to know the failing command.

## Revision 2 changes

- Fixed an incorrect cache key that relied on `hmm.json` being visible in the GitHub repository even though it is only inside the ZIP. Libraries are now cached using the uploaded ZIP's content hash.
- Matched upstream Funkin's patched Haxelib installation sequence more closely, including selecting Haxelib 4.1.0 before patch installation.
- Kept Haxe and C++ tools pinned and installed Android platform/NDK versions from Funkin's mobile compiling guide.
- Deferred Git LFS file downloads to an explicit `git lfs pull`, providing a clearer error if downloading assets fails.
- **Fixed missing Android icons:** Fetches `art/icons` and `art/readme.txt` from FunkinCrew’s separate art repository using a sparse checkout, without downloading huge raw art files.
- Added build logs as an artifact even after failure; ZIP validation rejects unsafe paths.
- Builds arm64 Android by disabling the older ARMv7 architecture to save CI time; test-device compatibility still needs confirmation.

## Limitations

**This workflow has been YAML-checked and the source contract tests passed locally. A real Android compilation has not been run or confirmed.** The images of the earlier run show only a generic exit code, not its failing command; these changes address known workflow weaknesses but may not resolve the exact original error.

`assets` and `art` were not in the original source upload, so CI fetches required files from the public FunkinCrew asset and art repositories. Assets use a separate licence and cannot be freely republished. The newest asset revision may not match the source revision. The build installs more than 30 Haxe libraries and compiles native code; it may be resource intensive. The temporary signing key used for an unsigned test APK changes across runs and is not suitable for production distribution or updating existing installations.
