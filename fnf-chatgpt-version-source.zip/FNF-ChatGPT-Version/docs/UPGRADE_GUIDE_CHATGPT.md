# FNF: ChatGPT Version — Fork Upgrade Guide

This is an **unofficial, community source fork** of Friday Night Funkin', not an official game from The Funkin' Crew or OpenAI. Original game source and branding remain credited in `LICENSE.md` and `README.md`.

## What changed

- **New main menu:** Replaced per-button animated atlas graphics with solid-color interactive cards, neon accent strips, readable labels, and a two-column violet/cyan/pink design. Kept existing game state transitions and selection logic.
- **More consistent menus:** Replaced the options menu's full-screen HSV-shader background with lightweight reusable `ChatGPTTheme` components. Added stylistically matched title, Freeplay, story and pause branding, plus a small gameplay HUD edition marker.
- **Touch-friendly navigation:** Main menu selection uses geometric hitboxes instead of expensive pixel-perfect collision checks, preserving two-tap confirmation. Keyboard and controller selection still use the existing `MenuTypedList`.
- **Updated app identity:** Desktop title and executable, home-screen title, and a separate unofficial mobile package name are set in `project.hxp` to avoid overwriting the official app.
- **Performance Mode setting:** An opt-in saved setting disables optional note splashes and hold-cover animations during gameplay without altering timing/scoring. Default is off.
- **Security improvements:** Hardened Linux URL launching, WebView URL validation, file-path containment, and ZIP imports. See `SECURITY_AUDIT_CHATGPT.md`.

**Performance expectation:** Less animated menu-atlas loading and no options-background HSV pass *should* reduce menu GPU/texture cost on lower-end devices. FPS improvement has **not been measured**. No global gameplay FPS cap or audio timing changes were made, to avoid breaking rhythm synchronization.

## Build requirements

The uploaded source ZIP contains empty `assets` and `art` directories because the original repository uses Git submodules. There is no compiled Android APK, Windows EXE or verified playable game in this bundle.

1. Use a local Haxe and HaxeFlixel/OpenFL build setup appropriate for this source revision (see `docs/COMPILING.md` and `docs/COMPILING_MOBILE.md`).
2. Clone/fetch the required original project submodules according to their licenses and repository instructions; do not assume the archive already includes their contents.
3. Install dependencies listed in `hmm.json` with `hmm install`.
4. Run `python3 tests/test_chatgpt_patch.py` for static checks.
5. Build using `lime test windows`, `lime test linux`, `lime test html5`, or Android build instructions in the existing documentation. Check release profiles and platform capabilities first.
6. Test menu navigation, charts, song timing, audio, mod imports, downloads, window title and mobile inputs before distribution.

## Known limitations

- This is a **first-pass source redesign**, not a complete replacement of all original artwork, every editor dialog, character-select interface, or in-song HUD. Those still use original assets.
- No real-device profiling, emulator run, dependency vulnerability database scan, or full Haxe compile could be performed from this snapshot.
- The initial splash, game music, charts and animations still require the original asset submodule and may carry separate rights restrictions.
- If building a mobile release under the new package name, ad, in-app purchase, store and social integrations must be reconfigured and should not use the original publisher's credentials.

## Files to inspect

`source/funkin/ui/ChatGPTTheme.hx`, `source/funkin/ui/mainmenu/MainMenuState.hx`, `source/funkin/ui/MenuList.hx`, `source/funkin/ui/options/OptionsState.hx`, `source/funkin/ui/title/TitleState.hx`, `source/funkin/ui/story/StoryMenuState.hx`, `source/funkin/ui/freeplay/FreeplayState.hx`, `source/funkin/play/PauseSubState.hx`, `source/funkin/play/PlayState.hx`, `source/funkin/util/WindowUtil.hx`, `source/funkin/mobile/util/WebViewUtil.hx`, `source/funkin/util/FileUtil.hx`, `project.hxp`.
