# FNF: ChatGPT Version — Source Security Review

**Review date:** 8 November 2026  
**Scope:** The uploaded `Funkin-main.zip` source snapshot (Haxe/OpenFL), not all upstream submodules, third-party libraries, built executables or servers.  
**Assessment type:** Manual targeted source inspection and automated source-contract checks. This is **not** an independent penetration test or a guarantee that the game is vulnerability-free.

## Findings and changes

| ID | Severity | Finding | Change | Verification |
| --- | --- | --- | --- | --- |
| CGPT-01 | High if an untrusted URL reaches this call | Linux `WindowUtil.openURL` interpolated a validated URL into a shell command. `&` is accepted in URL query strings and is a shell command separator. | Changed to `Sys.command('/usr/bin/xdg-open', [targetUrl])` so the URL is a separate argument instead of shell source. | Static regression check; native runtime not available. |
| CGPT-02 | Medium | `FileUtilSandboxed.sanitizePath` used a simple path prefix check, which incorrectly considers `/game-backup` inside `/game`. | Normalize separators and compare the complete directory boundary (`root` or `root + '/'`), case-folding on Windows. | Static regression check; symlink/race testing pending. |
| CGPT-03 | Medium | `FileUtil.readZIPFromBytes` previously extracted entries without explicit entry count or advertised decompressed-size limits. Untrusted ZIP files might exhaust memory; names containing traversal components could reach callers. | Added 128 MiB compressed archive cap, 64 MiB per-file cap, 512 MiB total advertised decompressed cap, 10,000-entry cap and basic path traversal / absolute path rejection. | Static regression check; decompressor and import functionality must be tested in game. |
| CGPT-04 | Low / defence in depth | Mobile embedded WebView did not use `WindowUtil.sanitizeURL` before opening the target. | Apply the same URL validation used by desktop to WebView links. | Static regression check; mobile runtime test pending. |

The severity estimates are conditional on actual reachable inputs. Not all findings have been proven exploitable through normal gameplay or bundled user interfaces.

## Other code paths checked

- `PolymodHandler.hx` includes import restrictions for `Sys`, direct library loading and untrusted scripting APIs. These are positive defences, but scripting isolation was not comprehensively audited.
- Native external-program calls in `FileUtil.hx` generally use argument arrays (unlike the old `WindowUtil` call).
- The `hmm.json` dependency list pins git revisions, but the source package lacks dependency checkouts, so no CVE correlation or transitive dependency scan was performed.

## Residual risks / actions before shipping

1. Run Haxe compilation and function tests with the full asset submodule; this environment had no Haxe/haxelib installation and the uploaded ZIP did not contain the source game's proprietary art/audio assets.
2. Verify the main menu with keyboard, controller and multitouch; validate different camera aspect ratios and notches.
3. Exercise ZIP import with safe normal charts, directories, malformed archives, high compression ratios and path traversal entries. The API is still a **whole-archive, in-memory** reader and cannot safely process arbitrarily huge files.
4. Check canonical path handling and symlink race cases on the supported OS targets. A race between validation and file use is not eliminated by a prefix check.
5. Perform dependency vulnerability scanning, script-sandbox fuzzing, release build smoke tests and relevant privacy / telemetry review.
6. Do not include unknown mods from untrusted sources in releases without separate review.

## Testing performed

`python3 tests/test_chatgpt_patch.py` is a source-contract regression suite. It checks that the security mitigations and visual integration hooks are present. It does **not** compile or execute Haxe. It should be complemented by desktop and Android build tests, performance profiling, and manual gameplay QA.
